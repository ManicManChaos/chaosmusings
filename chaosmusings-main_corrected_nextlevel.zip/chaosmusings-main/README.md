# chaosmusings

iPad-only. Right-edge sidebar. CST timebase.
Set Vercel env vars:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY

## Asset rule

All icons/images must be referenced via `lib/assets.js`. Do not hardcode `/public` paths inside components.

