export default function CallbackPage() {
  return <div style={{ padding: 16 }}>Auth callback.</div>;
}