export default function ContextFeed() {
  return (
    <section className="section" aria-label="The Context feed">
      <h2>The Context</h2>
      <div style={{ opacity: 0.8 }}>
        Display-only feed. Entries appear here after completing:
        Moments / Roid Boy / P.S.
      </div>
    </section>
  );
}
