export default function SummationPreview() {
  return (
    <section className="section" aria-label="The Summation preview">
      <h2>The Summation</h2>
      <div style={{ opacity: 0.8 }}>Preview only. Full writing in Summation overlay.</div>
    </section>
  );
}
