import { ICONS } from "@/lib/assets";

export default function Glyph({ id, label, className = "" }) {
  const src = ICONS[id] || `/icons/${id}.svg`;

  return (
    <button className={`runeBtn ${className}`} type="button" aria-label={label}>
      <img className="runeImg" src={src} alt="" />
    </button>
  );
}
