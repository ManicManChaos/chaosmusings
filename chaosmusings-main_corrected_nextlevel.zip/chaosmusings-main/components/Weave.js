"use client";

export default function Weave() {
  return (
    <div className="weaveOverlay" aria-hidden="true">
      <div className="weaveField" />
      <div className="weavePulse" />
    </div>
  );
}
